class ProviderPage {

    // preencheSelect(nomeGet,nomeCampo) {
    //     cy.get(`app-select-custom[name="${nomeGet}"]`).click()
    //     // cy.get('span.ng-star-inserted').contains(nomeCampo).click()
    //     cy.get('input[name="pesquisar"]').type(nomeCampo)
    //     cy.get('span[class="mat-option-text"]').contains(nomeCampo).click()
    //     // cy.get('body').trigger('keydown', { keyCode: 27 });
    // }

    // preencheInput(nomeGet, nomeCampo) {
    //     cy.get(`app-input-text-custom[name="${nomeGet}"]`).type(nomeCampo)
    // }
    
    login() {
        cy.visit('/login')
        
        cy.get('#mat-input-0').type("agropecuariacelf@gmail.com")
        cy.get('#mat-input-1').type("123")
        cy.get(':nth-child(1) > .btn-block').click()
    }

    goTo() {
        cy.wait(1000)
        cy.get('.mat-drawer-inner-container > :nth-child(2)').click().wait(400)
        cy.get('[routerlink="/menu/cadastro/transportador"]').click().wait(400)
        cy.get('.btn').click().wait(400)
    }

    fillForm(transportador) {
        // // cy.get('app-input-text-custom[name="nome"]').type(transportador.nome)
        // this.preencheInput('nome', transportador.nome)
        // this.preencheInput('cpf_cnpj', transportador.cpf_cnpj)
        // // this.preencheInput('inscricaoEstadual', transportador.inscricaoEstadual)
        // // this.preencheSelect('estado', transportador.estado)
        // // this.preencheSelect('cidade', transportador.cidade)
        // this.preencheInput('endereco', transportador.endereco)
        // // this.preencheInput('descricaoVeiculo', transportador.descricaoVeiculo)
        // this.preencheInput('placa', transportador.placa)

        
        
        // this.preencheSelect('idUfPlaca', transportador.idUfPlaca)


        cy.get('app-input-text-custom[name="cpf_cnpj"]').type(transportador.cpf_cnpj)
        cy.get('app-input-text-custom[name="inscricaoEstadual"]').type(transportador.incricaoEstadual)
        cy.get('app-input-text-custom[name="estado"]').type(transportador.estado)
        cy.get('app-input-text-custom[name="cidade"]').type(transportador.cidade)
        cy.get('app-input-text-custom[name="endereco"]').type(transportador.endereco)
        cy.get('app-input-text-custom[name="descricaoVeiculo"]').type(transportador.incricaoEstadual)
        cy.get('app-input-text-custom[name="placa"]').type(transportador.placa)
        cy.get('app-input-text-custom[name="idUfPlaca"]').type(transportador.idUfPlaca)
    }
    save() {
        cy.get(':nth-child(2) > .btn-block').click()
    }
}


export default new ProviderPage;