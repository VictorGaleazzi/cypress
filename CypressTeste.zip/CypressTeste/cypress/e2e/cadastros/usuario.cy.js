import dados from '../pages/registration/UserPage'

context('leigado', () => {
  beforeEach(function() {
    cy.restoreLocalStorage();
    cy.fixture('login/acesso').then((l) => {
      this.acesso = l
    });
    cy.fixture('cadastros/cadastroUsuario').then((cad) => {
      this.cadastroUsuario = cad
    });
  });

  it('Cadastro Usuário', function() {

    dados.login(this.acesso.logando);
    dados.goTo();
    dados.fillForm(this.cadastroUsuario.cadastrando);
    dados.save();
  });

  afterEach(() => {
    cy.saveLocalStorage();
  });
});  