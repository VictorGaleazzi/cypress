class PropertyPage {
    login(){
        cy.visit('/login')

        cy.get('#mat-input-0').type("agropecuariacelf@gmail.com")
        cy.get('#mat-input-1').type("123")
        cy.get(':nth-child(1) > .btn-block').click()
    }

    goTo() {
        cy.wait(1000)
        cy.get('.mat-drawer-inner-container > :nth-child(2)').click()
        cy.get('[routerlink="/menu/cadastro/propriedade"]').click()
        cy.get('.btn').click()
    }

    fillForm(propriedade){
        cy.get('app-input-text-custom[name="razaoSocial"]').type(propriedade.razaoSocial)
        cy.get('app-input-text-custom[name="nomePropriedade"]').type(propriedade.nomePropriedade)
        cy.get('app-input-text-custom[name="nomeDonoPropriedade"]').type(propriedade.nomeProprietario)
        cy.get('app-input-text-custom[name="tamanho"]').type(propriedade.hectares)
        cy.get('app-input-text-custom[name="telefone"]').type(propriedade.telefone)
        // cy.get('app-input-text-custom[name="cpf_cnpj"]').type(propriedade.cpfCnpj)

        cy.get('app-input-text-custom[name="endereco"]').type(propriedade.endereco.rua)
        cy.get('app-input-text-custom[name="numero"]').type(propriedade.endereco.numero)
        cy.get('app-input-text-custom[name="bairro"]').type(propriedade.endereco.bairro)
        cy.get('app-input-text-custom[name="cep"]').type(propriedade.endereco.cep)
        cy.get('app-input-text-custom[name="complemento"]').type(propriedade.endereco.complemento)

        cy.get(':nth-child(2) > app-select-custom.ng-star-inserted > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click().wait(300)
        cy.get('#mat-input-5').type(propriedade.endereco.estado)
        cy.get('#mat-option-46 > .mat-option-text > .ng-star-inserted').click()

        cy.get(':nth-child(3) > app-select-custom.ng-star-inserted > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click().wait(300)
        cy.get('#mat-input-6').type(propriedade.endereco.cidade)
        cy.get('#mat-option-100 > .mat-option-text > .ng-star-inserted').click()

        // cy.get('#mat-slide-toggle-2 > .mat-slide-toggle-label > .mat-slide-toggle-bar').click().wait(200)
        // cy.get('app-input-text-custom[name="inscricaoEstadual"]').type(propriedade.endereco.nfe.inscricaoEstadual)
    }

    notaFiscal() {
        // cy.get('app-input-text-custom[name="inscricaoEstadual"]').type('SEI LA')
        // cy.get(':nth-child(5) > :nth-child(3) > app-select-custom > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click()
        // cy.get('#mat-option-113 > .mat-option-text > .ng-star-inserted').click()
    }

    save() {
        cy.get('button').contains('Salvar').click()
    }
}

export default new PropertyPage;