import medicine from '../pages/registration/MedicinePage' 

context('leigado', () => {
  
    beforeEach(function() {
        cy.restoreLocalStorage();
        cy.fixture('cadastros/medicamento').then((med) => {
          this.medicamento = med
        })
    });

    it('Cadastrando', function() {

      medicine.login()
      medicine.goTo()
      medicine.fillForm(this.medicamento.cadastrando)
      medicine.save()
    });

    afterEach(() => {
        cy.saveLocalStorage();
    });
});
