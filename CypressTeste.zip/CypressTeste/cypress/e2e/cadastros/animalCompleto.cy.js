import signup from '../pages/registration/CompleteAnimalRegistration'

describe('leigado', () => {

    beforeEach(function() {
      cy.restoreLocalStorage();
      cy.fixture('login/acesso').then((l) => {
        this.acesso = l
      });
      cy.fixture('cadastros/animalCompleto').then((ac) => {
        this.animalCompleto = ac
      })
    });

    it('Cadastro Animal', function() {

      signup.login(this.acesso.logando)
      signup.go()
      signup.fillForm(this.animalCompleto.cadastrando)
      signup.save()
    })

    afterEach(() => {
      cy.saveLocalStorage();
    });
})