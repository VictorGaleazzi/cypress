import customerSupplier from '../pages/registration/CustomerSupplier'

context('leigado', () => {
  
    beforeEach(function() {
        cy.restoreLocalStorage();
        cy.fixture('cadastros/clienteFornecedor').then((cf) => {
            this.clienteFornecedor = cf
        })
    });

    it('Cadastrando', function() {

        customerSupplier.login()
        customerSupplier.goTo()
        customerSupplier.fillForm(this.clienteFornecedor.cadastrando)
        customerSupplier.save()
    })

    afterEach(() => {
        cy.saveLocalStorage();
    });
})