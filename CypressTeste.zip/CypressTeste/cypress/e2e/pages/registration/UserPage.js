class UserPage {

    preencheSelect(nomeGet,nomeCampo) {
        cy.get(`app-select-custom[name="${nomeGet}"]`).click()
        cy.get('span.ng-star-inserted').contains(nomeCampo).click()
        cy.get('body').trigger('keydown', { keyCode: 27 });
    }
    
    login(login) {
        cy.visit('/login')
        
        cy.get('#mat-input-0').type(login.email)
        cy.get('#mat-input-1').type(login.senha)
        cy.get(':nth-child(1) > .btn-block').click()
    }

    goTo() {
        cy.wait(1000)
        cy.get('.mat-drawer-inner-container > :nth-child(2)').click().wait(400)
        cy.get('[routerlink="/menu/cadastro/usuario"]').click().wait(400)
        // cy.get('.btn').click().wait(400)
        cy.get('button').contains('Cadastrar').click()
    }

    fillForm(novoUsuario) {
        cy.get('#mat-input-9').type(novoUsuario.nome)
        cy.get('#mat-input-10').type(novoUsuario.email)
        cy.get('#mat-input-5').type(novoUsuario.confirmarEmail)
        cy.get('#mat-input-11').type(novoUsuario.cpf_cnpj)
        cy.get('#mat-input-12').type(novoUsuario.telefone)
        cy.get('#mat-input-6').type(novoUsuario.senha)
        cy.get('#mat-input-7').type(novoUsuario.confirmarSenha)
      
        this.preencheSelect('propriedadesSelecionadas',novoUsuario.propriedades)
    
    }

    save() {
        cy.get(':nth-child(2) > .btn-block').click()
    }
}

export default new UserPage;