import fastRegistration from '../pages/registration/FastAnimalRegistration'

context('leigado', () => {
  
    beforeEach(() => {
      cy.restoreLocalStorage();
    });

    it('Cadastro Rápido', () => {
      fastRegistration.login()
      fastRegistration.goTo()
      fastRegistration.save()
    })

    afterEach(() => {
      cy.saveLocalStorage();
    });
})  