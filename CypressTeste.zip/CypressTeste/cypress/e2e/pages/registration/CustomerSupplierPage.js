class CustomerSupplier {
    
    login() {
        cy.visit('/login')

        cy.get('#mat-input-0').type("agropecuariacelf@gmail.com")
        cy.get('#mat-input-1').type("123")
        cy.get(':nth-child(1) > .btn-block').click()
    }

    goTo() {
        cy.wait(1000)
        cy.get('.mat-drawer-inner-container > :nth-child(2)').click().wait(400)
        cy.get('[routerlink="/menu/cadastro/cliente-fornecedor"]').click().wait(400)
        cy.get('button').contains('Cadastrar').click().wait(400)
    }

    fillForm(dados) {
        cy.get('app-input-text-custom[name="nome"]').type(dados.nome)
        cy.get('app-input-text-custom[name="celular"]').type(dados.celular)
        cy.get('app-input-text-custom[name="telefone"]').type(dados.telefone)
        cy.get('app-input-text-custom[name="email"]').type(dados.email)
        cy.get('app-input-text-custom[name="cpf_cnpj"]').type(dados.cpfCnpj)
        cy.get('app-input-text-custom[name="inscricaoEstadual"]').type(dados.ie)
        cy.get('app-input-text-custom[name="endereco"]').type(dados.endereço)
        cy.get('app-input-text-custom[name="numero"]').type(dados.numero)
        cy.get('app-input-text-custom[name="bairro"]').type(dados.bairro)
        cy.get('app-input-text-custom[name="complemento"]').type(dados.complemento)
        cy.get('app-input-text-custom[name="cep"]').type(dados.cep)
        
        cy.get('body').trigger('keydown', { keyCode: 27})

        cy.get(':nth-child(7) > app-select-custom > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click().wait(400)
        cy.get('#mat-input-5').type('Paraná')
        cy.get('body').trigger('keydown', { keyCode: 27})


        cy.get(':nth-child(8) > app-select-custom > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click().wait(400)
        cy.get('#mat-input-6').type('Dois Vizinhos').wait(200)
        cy.get('body').trigger('keydown', { keyCode: 27})

    }

    save() {
        cy.get(':nth-child(2) > .btn-block').click()
    }
}

export default new CustomerSupplier;