import employee from '../pages/registration/EmployeePage'

context('leigado', () => {
  
    beforeEach(function() {
        cy.restoreLocalStorage();
        cy.fixture('cadastros/funcionarioAssistente').then((f) => {
            this.funcionarioAssistente = f 
        })
    })

    it('Cadastro', function() {
        
        employee.login();
        employee.goTo();
        employee.fillForm(this.funcionarioAssistente.cadastrando);
        employee.save();
    })
    
    afterEach(() => {
        cy.saveLocalStorage();
    });
})