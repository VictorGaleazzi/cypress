class CompleteAnimalRegistration {

    preencheSelect(nomeGet,nomeCampo) {
        cy.get(`app-select-custom[name="${nomeGet}"]`).click()
        // cy.get('span.ng-star-inserted').contains(nomeCampo).click()
        cy.get('input[name="pesquisar"]').type(nomeCampo)
        cy.get('span[class="mat-option-text"]').contains(nomeCampo).click()
        // cy.get('body').trigger('keydown', { keyCode: 27 });
    }

    preencheInput(nomeGet, nomeCampo) {
        cy.get(`app-input-text-custom[name="${nomeGet}"]`).type(nomeCampo)
    }



    //logar na pagina
    login(login) {
        cy.visit('/login')

        cy.get('#mat-input-0').type(login.email)
        cy.get('#mat-input-1').type(login.senha)
        cy.get(':nth-child(1) > .btn-block').click()
    }

    //Acessar página de cadastro animal
    go() {
        cy.wait(500)
        cy.get('.mat-drawer-inner-container > :nth-child(2)').click().wait(400)
        cy.get('[routerlink="/menu/cadastro/animal"]').click().wait(400)
        cy.get('.mr-2 > .btn').click()
    }

    
    fillForm(novoCadastro) {
        cy.wait(1000)
        
        this.preencheInput('brinco', novoCadastro.brinco)//Brinco
        this.preencheInput('brincoEletronico', novoCadastro.brincoEletronico)//Brinco eletronico
        this.preencheInput('registro', novoCadastro.registro)//Registro
        this.preencheInput('nome', novoCadastro.nome)//Nome

        //Lote
        this.preencheSelect('lote', novoCadastro.lote)
        
        //Nascimento
        cy.get('app-datepicker-custom[name="dtNascimento"]').type(novoCadastro.dataNascimento)

        //Raça
        this.preencheSelect('raca', novoCadastro.raca)
        cy.get('body').trigger('keydown', { keyCode: 27 });
        
        //Grau sanguineo
        // this.preencheSelect('grauSanguineo', novoCadastro.grauSanguineo)

        //Origem
        this.preencheSelect('tipo', novoCadastro.origem)
        
        //Preço
        this.preencheInput('preco', novoCadastro.preco)

        //Data Desmame
        cy.get('app-datepicker-custom[name="dtDesmame"]').type(novoCadastro.dataDesmame)
        cy.get('body').trigger('keydown', { keyCode: 27 });

        //Cliente-Fornecedor
        this.preencheSelect('clienteFornecedor', novoCadastro.clienteFornecedor)
        cy.get('body').trigger('keydown', { keyCode: 27 });

        //Peso de Nascimento    
        cy.get('app-input-text-custom[name="pesoNascimento"]').type(novoCadastro.pesoAoNascer)
    
        //Observação
        cy.get('textarea[id="mat-input-6"]').type(novoCadastro.observacao)
    }

    save() {
        cy.get('button').contains('Salvar').click()
    }
}

export default new CompleteAnimalRegistration;