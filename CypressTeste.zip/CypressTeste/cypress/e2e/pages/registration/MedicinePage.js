class MedicinePage {

    login() {
        cy.visit('/login')

        cy.get('#mat-input-0').type("agropecuariacelf@gmail.com")
        cy.get('#mat-input-1').type("123")
        cy.get(':nth-child(1) > .btn-block').click()
    }

    goTo() {
        cy.wait(1000)
        cy.get('.mat-drawer-inner-container > :nth-child(2)').click().wait(400)
        cy.get('[routerlink="/menu/cadastro/medicamento"]').click().wait(400)
        cy.get('button').contains('Cadastrar').click()
    }

    fillForm(medicamento) {
        cy.wait(1000)
        cy.get('app-input-text-custom[name="nome"]').type(medicamento.nome).wait(300)
        cy.get('app-input-text-custom[name="diasCarencia"]').type(medicamento.diasCarencia).wait(300)
        
        cy.get('.btn-block > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click()
        cy.get('#mat-input-8').type(medicamento.unidadeEntrada)
  
        cy.get('#mat-option-9 > .mat-option-text').click()
        cy.get('app-input-text-custom[name="qtdEntrada"]').type(medicamento.quantidade).wait(300)
        cy.get('#mat-option-32 > .mat-option-text > .ng-star-inserted').click()
  
        cy.get('.ng-untouched > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex').click().wait(300)
        cy.get('#mat-input-10').type(medicamento.unidadeSaida).wait(100)
        cy.get('#mat-option-42 > .mat-option-text').click().wait(100)
      
        cy.get('app-input-text-custom[name="precoCusto"]').type(medicamento.precoCusto).wait(300)
  
        cy.get('#mat-input-5').type(medicamento.modoUso)
    }

    save() {
        cy.get('button').contains('Salvar').click()
        cy.get('button').contains('Voltar').click()
    }
}

export default new MedicinePage;