class FastAnimalRegisstration {

    login() {
        cy.visit('/login')
      
        cy.get('#mat-input-0').type("agropecuariacelf@gmail.com")
        cy.get('#mat-input-1').type("123")
        cy.get(':nth-child(1) > .btn-block').click()
    }

    goTo() {
        cy.wait(2000)
        cy.get('.mat-drawer-inner-container > :nth-child(2)').click().wait(400)
        cy.get('[routerlink="/menu/cadastro/animal"]').click().wait(400)
        cy.get('.col-lg-3.ng-star-inserted > .btn').click()
        
        cy.wait(2000)
        cy.get(':nth-child(1) > app-input-text-custom.ng-untouched > .inline-group > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').type('2564') 
        cy.get(':nth-child(1) > .row.ng-untouched > .row > :nth-child(2) > app-input-text-custom.ng-untouched > .inline-group > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex').type('vaquinha')
  
        cy.get(':nth-child(1) > .row.ng-untouched > .row > :nth-child(3) > .inline-group > .btn-block > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click()
        cy.get('#mat-option-11 > .mat-option-text > .ng-star-inserted').click()
        cy.get('#mat-option-20 > .mat-option-text > .ng-star-inserted').click()
  
        cy.wait(300)
        cy.get('body').type('{esc}')
  
        cy.get('app-datepicker-custom[formcontrolname="dtNascimento"]').find('input').first().type('2021-05-17',{force: true})
        cy.get('app-datepicker-custom[formcontrolname="dtInicioLactacao"]').find('input').first().type('2022-10-17',{force:true})
    }

    save() {
        cy.wait(300)
        cy.get(':nth-child(2) > .btn-block').click()
    }
}

export default new FastAnimalRegisstration;