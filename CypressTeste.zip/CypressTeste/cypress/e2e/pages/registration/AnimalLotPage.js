class AnimalLotPage {

    tirarFoco() {
        cy.get('body').trigger('keydown', { keyCode: 27, which: 27 })
    }
    
    login() {
        cy.visit('/login')

        cy.get('#mat-input-0').type("agropecuariacelf@gmail.com")
        cy.get('#mat-input-1').type("123")
        cy.get(':nth-child(1) > .btn-block').click()

    }

    goTo() {
        cy.wait(500)
        cy.get('.mat-drawer-inner-container > :nth-child(2)').click()
        cy.get('[routerlink="/menu/cadastro/lote"]').click()
        cy.get('.btn').click()

    }

    fillForm(cadastroLote) {
        cy.wait(500)
        cy.get('app-input-text-custom[name="nome"]').type(cadastroLote.nomeLote)

        cy.get(':nth-child(2) > app-select-custom > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click().wait(300)
        cy.get('#mat-input-7').type(cadastroLote.faseLote)
        cy.get('span[class="mat-option-text"]').contains('Vacas secas').click().wait(300)

        cy.get(':nth-child(3) > app-select-custom > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click().wait(100)
        cy.get('#mat-input-8').type(cadastroLote.sexo)
        this.tirarFoco()

        cy.get(':nth-child(5) > app-select-custom > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click().wait(100)
        cy.get('#mat-input-10').type('Por peso total')
        // this.tirarFoco()
        cy.get('#mat-option-26 > .mat-option-text').click()



        cy.get('app-input-text-custom[name="minPeso"]').type(cadastroLote.campoVariavel.pesoMin)
        cy.get('app-input-text-custom[name="maxPeso"]').type(cadastroLote.campoVariavel.pesoMax)
        
        cy.get('app-input-text-custom[name="descLote"]').type(cadastroLote.descricao)
    }

    save() {
        cy.get('button').contains('Salvar').click()
    }
}

export default new AnimalLotPage;