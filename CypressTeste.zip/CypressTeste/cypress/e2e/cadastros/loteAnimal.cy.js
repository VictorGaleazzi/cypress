import lotRegister from '../pages/registration/AnimalLotPage'

describe('Lote Animal', () => {

    beforeEach(function() {
        cy.restoreLocalStorage();
        cy.fixture('cadastros/loteAnimal').then((la) => {
            this.loteAnimal = la
        })
    });

    it('Cadastrando', function() {

        lotRegister.login()
        lotRegister.goTo()
        lotRegister.fillForm(this.loteAnimal.cadastrando)
        lotRegister.save()
        })

        afterEach(() => {
            cy.saveLocalStorage();
        });
})