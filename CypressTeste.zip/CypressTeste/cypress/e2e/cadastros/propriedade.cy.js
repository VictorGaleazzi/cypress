import property from '../pages/registration/PropertyPage'

context('leigado', () => {
  
    beforeEach(function() {
        cy.restoreLocalStorage();
        cy.fixture('cadastros/propriedade').then((prop) => {
            this.propriedade = prop
        })
    });
    
    it('Cadastro', function() {

        property.login()
        property.goTo()
        property.fillForm(this.propriedade.cadastrando)
        property.save()
        });

    afterEach(() => {
        cy.saveLocalStorage();
    });
})
