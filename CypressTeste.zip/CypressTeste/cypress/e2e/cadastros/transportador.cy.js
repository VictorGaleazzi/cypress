import theProvider from '../pages/registration/ProviderPage'

context('leigado', () => {
  
    beforeEach(function() {
        cy.restoreLocalStorage();
        cy.fixture('cadastros/transportador').then((t) => {
            this.transportador = t
          })
    });
    
    it('Cadastro Transportador', function() {

        theProvider.login()
        theProvider.goTo()
        theProvider.fillForm(this.transportador.cadastrando)
        theProvider.save()
        });

    afterEach(() => {
        cy.saveLocalStorage();
    });
})
