class EmployeePage {
    
    login() {
        
        cy.visit('/login')

        cy.get('#mat-input-0').type("agropecuariacelf@gmail.com")
        cy.get('#mat-input-1').type("123")
        cy.get(':nth-child(1) > .btn-block').click()
    }

    goTo() {
        cy.wait(1000)
        cy.get('.mat-drawer-inner-container > :nth-child(2)').click()
        cy.get('[routerlink="/menu/cadastro/funcionario"]').click()
        cy.get('.btn').click()

    }

    fillForm(funcionario) {
        cy.get('app-input-text-custom[name="nome"]').type(funcionario.nome)
        // cy.get('app-input-text-custom[name="cpf"]').type(funcionario.cpf)
        // cy.get('app-input-text-custom[name="dtNascimento"]').click().type(funcionario.dataNascimento)
        cy.get(':nth-child(3) > app-datepicker-custom.ng-untouched > .mat-form-field > .mat-form-field-wrapper > .mat-form-field-flex > .mat-form-field-infix').click().type(funcionario.dataNascimento)
        cy.get('app-input-text-custom[name="telefone"]').type(funcionario.telefone)
        cy.get('app-input-text-custom[name="salario"]').type(funcionario.salario)
        cy.get('app-datepicker-custom[name="dtAdmissao"]').type(funcionario.dataAdmissiao)
        cy.get('app-datepicker-custom[name="dtDemissao"]').click().type(funcionario.dataDemissao)
        cy.get('app-select-custom[name="diaPagamentoSalario"]').click()
        cy.get('#mat-input-12').type(funcionario.diaPagamento)
        cy.get('body').trigger('keydown', { keyCode: 27, which: 27 })

        // cy.get('#mat-option-13 > .mat-option-text').click()
    }

    save() {
        cy.get('button').contains('Salvar').click()

    }
}

export default new EmployeePage;